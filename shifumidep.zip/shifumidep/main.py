import tensorflow as tf 
import numpy as np
import picamera

#Chargement du modele
interpreter=tf.lite.Interpreter(model_path="converted_model.tflite")
interpreter.allocate_tensors()
#Recuperation des entrés et sorties du tensor 
input_details=interpreter.get_input_details()
output_details=interpreter.get_output_details()

#recuperation des images de la camera 

with picamera.PiCamera() as camera:
    camera.resolution=(640,480)
    while True:
        image=np.empty((480,640,3), dttype=np.uint8)
        camera.capture(image,'rgb')

height,width, __ =frame.shape
new_width,new_height=(300,300)

left=(width-new_width)//2
top=(height-new_height)//2
right=(width+new_width)//2
bottom=(height+new_height)//2

image=frame[left:right, top:bottom, :]

def detect(self, image, threshold=0.1):
    frame=np.expand_dims(image, axis=0)

    self.interpreter.set_tenso(self.input_details[0]['index'], frame)
    self.interpreter.invoke()

boxes=interpreter.get_tensor(output_details[0]['index'])[0]
classes=interpreter.get_tensor(output_details[1]['index'])[0]
scores=interpreter.get_tensor(output_details[2]['index'])[0]
num_detection=interpreter.get_tensor(output_details[3]['index'])[0]

min_score_tresh=0.6
number_boxes= boxes.shape[0]
detected_boxes=[]
probabilities=[]
categories=[]

for i in range (number_boxes):
    if scores is None or scores[i]>min_score_tresh:
        box=tuple(boxes[i].tolist())
        detected_boxes.append(box)
        probabilities.append(scores[i])
        categories.append(self.category_index[classes[i]])


(top, bottom, left, right)=(top * im_height, bottom * im_height, left * im_height, right * im_width )
draw.line([(left, top), (left, bottom), (right, bottom), (right,top),(left, top)], width=thickness,fill=color)
draw.text(
    (left + margin, text_bottom - text_height - margin),
    display_str,
    fill='black',
    font=font)



import numpy as np
import tflite_runtime.interpreter as tflite
import picamera 
import argparse
import matplotlib as plt 

from tensorflow.lite.python import convert_saved_model
from affichage import raw_bounding_boxes_on_image_array
from tflite_runtime.interpreter import Interpreter 


#Chargement du modele
parser=argparse.ArgumentParser(description='shifumi')
parser.add_argument('--filename',type=str, help='Specify the filename',required=True)
parser.add_argument('--model_path',type=str, help='Specify the model path',required=True)
parser.add_argument('--label_path',type=str, help='Specify the label map',required=True)
parser.add_argument('--top_k',type=float, help='SHow many top results',default=0.6)

args=parser.parse_args()
filename=args.filename
model_path=args.model_path
label_path=args.label_path
top_k_results=args.top_k

with open(label_path, 'r') as f:
    labels=list(map(str.strip, f.readLines()))

interpreter=Interpreter(model_path)
interpreter.allocate_tensors()
#Recuperation des entrés et sorties du tensor 
input_details=interpreter.get_input_details()
output_details=interpreter.get_output_details()


"""Image and label map utility functions."""
import logging
import numpy as np

def create_category_index(categories):
  category_index = {}
  for index, cat in enumerate(categories):
    category_index[index] = cat
  return category_index

def load_labelmap(path):

  with open(path, 'r') as fid:
    label_map = list(map(str.strip, fid.readlines()))
  return label_map

def get_label_map_dict(label_map_path):
  label_map = load_labelmap(label_map_path)
  label_map_dict = {}
  for item in label_map.item:
    label_map_dict[item.name] = item.id
  return label_map_dict

def load_image(frame, new_size=(300, 300)):
  # Get the dimensions
  height, width, _ = frame.shape # Image shape
  new_width, new_height = new_size # Target shape 

  # Calculate the target image coordinates
  left = (width - new_width) // 2
  top = (height - new_height) // 2
  right = (width + new_width) // 2
  bottom = (height + new_height) // 2

  image = frame[left: right, top: bottom, :]
  return image



if __name__ == '__main__':
    args = parse_args()
    detector = converted_modelite(model_path=args.model_path, label_path=args.label_path)
    input_size = detector.get_input_size()

    plt.ion()
    plt.tight_layout()
    
    fig = plt.gcf()
    fig.canvas.set_window_title('Object Detection')
    fig.suptitle('Detecting')
    ax = plt.gca()
    ax.set_axis_off()
    tmp = np.zeros(input_size + [3], np.uint8)
    preview = ax.imshow(tmp)
    

    with picamera.PiCamera() as camera:
        camera.resolution = (640, 480)
        while True:
            stream = np.empty((480, 640, 3), dtype=np.uint8)
            camera.capture(stream, 'rgb')
          
            image = load_image(stream)
            boxes, scores, classes = detector.detect(image, args.confidence)
            for label, score in zip(classes, scores):
                print(label, score)
  
            if len(boxes) > 0:
                draw_bounding_boxes_on_image_array(image, boxes, display_str_list=classes)
            
            preview.set_data(image)
            fig.canvas.get_tk_widget().update()
            
    detector.close()


#recuperation des images de la camera 


"""height,width, __ =frame.shape
new_width,new_height=(300,300)

left=(width-new_width)//2
top=(height-new_height)//2
right=(width+new_width)//2
bottom=(height+new_height)//2

image=frame[left:right, top:bottom, :]

def detect(self, image, threshold=0.1):
    frame=np.expand_dims(image, axis=0)

    self.interpreter.set_tenso(self.input_details[0]['index'], frame)
    self.interpreter.invoke()

boxes=interpreter.get_tensor(output_details[0]['index'])[0]
classes=interpreter.get_tensor(output_details[1]['index'])[0]
scores=interpreter.get_tensor(output_details[2]['index'])[0]
num_detection=interpreter.get_tensor(output_details[3]['index'])[0]

min_score_tresh=0.6
number_boxes= boxes.shape[0]
detected_boxes=[]
probabilities=[]
categories=[]

for i in range (number_boxes):
    if scores is None or scores[i]>min_score_tresh:
        box=tuple(boxes[i].tolist())
        detected_boxes.append(box)
        probabilities.append(scores[i])
        categories.append(self.category_index[classes[i]])


(top, bottom, left, right)=(top * im_height, bottom * im_height, left * im_height, right * im_width )
draw.line([(left, top), (left, bottom), (right, bottom), (right,top),(left, top)], width=thickness,fill=color)
draw.text(
    (left + margin, text_bottom - text_height - margin),
    display_str,
    fill='black',
    font=font)"""


